	<footer>
		<div class = "appname">@shehan Geeth Chamara</div>
	</footer>

	<style type="text/css">
		
		footer{
			color: white;
			padding: 10px;
			background: black;
			overflow: auto;
		}

		footer .appname {
			text-align: center;
		}		


	</style>